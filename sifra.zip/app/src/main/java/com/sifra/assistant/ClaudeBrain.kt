package com.sifra.assistant

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class Action(val type: String, val args: JSONObject)
data class Plan(val say: String, val actions: List<Action>)

/** Voice command ko Google Gemini (free key) se samjhwa kar actions ki list banata hai. */
class ClaudeBrain(private val apiKey: String) {

    private val client = OkHttpClient.Builder()
        .callTimeout(30, TimeUnit.SECONDS)
        .build()

    private val system = """
You are Sifra, a personal voice assistant living inside the user's Android phone.
The user speaks Hindi/Hinglish/English. Reply in the same style, short and friendly.
Turn the user's command into JSON ONLY (no other text) in this exact shape:
{"say":"short spoken reply","actions":[ ... ]}

Allowed actions:
{"type":"call","target":"contact name or phone number"}
{"type":"sms","target":"contact name or phone number","text":"message"}
{"type":"open_app","app":"app name as shown on phone, e.g. WhatsApp, YouTube, Camera"}
{"type":"alarm","hour":7,"minute":30,"label":"text"}
{"type":"timer","seconds":300}
{"type":"search","query":"web search text"}
{"type":"flashlight","on":true}
{"type":"settings","page":"wifi|bluetooth|display|sound|main"}
{"type":"nav","name":"home|back|recents|notifications|quick_settings|scroll_down|scroll_up"}
{"type":"tap_text","text":"visible text of a button on screen"}

If it is just a question or chat, use an empty actions list and put the answer in "say" (max 2 sentences).
Never invent contacts or numbers. If something is unclear, ask in "say" with empty actions.
""".trimIndent()

    fun plan(command: String): Plan {
        val body = JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
            )
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", command)))
                )
            )
            .put(
                "generationConfig",
                JSONObject().put("responseMimeType", "application/json").put("maxOutputTokens", 500)
            )

        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(req).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                return Plan("Gemini se connect nahi ho paya. API key check karo.", emptyList())
            }
            val out = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            val s = out.indexOf('{')
            val e = out.lastIndexOf('}')
            if (s < 0 || e <= s) return Plan(out.take(200), emptyList())

            val j = JSONObject(out.substring(s, e + 1))
            val list = mutableListOf<Action>()
            val arr = j.optJSONArray("actions") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val a = arr.getJSONObject(i)
                list += Action(a.optString("type"), a)
            }
            return Plan(j.optString("say"), list)
        }
    }
}
