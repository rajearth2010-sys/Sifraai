package com.sifra.assistant

import org.json.JSONObject

/** Bina internet/API ke: fixed Hinglish/Hindi commands ko pehchanta hai. */
object LocalBrain {

    private val hindiNums = mapOf(
        "ek" to 1, "एक" to 1, "do" to 2, "दो" to 2, "teen" to 3, "तीन" to 3, "char" to 4, "चार" to 4,
        "paanch" to 5, "panch" to 5, "पाँच" to 5, "पांच" to 5, "chhe" to 6, "cheh" to 6, "छह" to 6, "छः" to 6,
        "saat" to 7, "सात" to 7, "aath" to 8, "आठ" to 8, "nau" to 9, "नौ" to 9, "das" to 10, "दस" to 10,
        "gyarah" to 11, "ग्यारह" to 11, "barah" to 12, "बारह" to 12
    )

    private fun act(type: String, vararg kv: Pair<String, Any>): Action {
        val o = JSONObject().put("type", type)
        kv.forEach { o.put(it.first, it.second) }
        return Action(type, o)
    }

    private fun has(t: String, vararg words: String) = words.any { t.contains(it) }

    private fun number(t: String): Int? {
        Regex("(\\d{1,3})").find(t)?.let { return it.groupValues[1].toInt() }
        for (w in t.split(" ", "-")) hindiNums[w]?.let { return it }
        return null
    }

    fun plan(raw: String): Plan {
        val t = raw.lowercase().trim().replace("।", "")
        if (t.isBlank()) return Plan("", emptyList())

        // ---- torch ----
        if (has(t, "torch", "flashlight", "टॉर्च", "टार्च", "फ्लैशलाइट")) {
            val off = has(t, "band", "off", "बंद", "ऑफ", "bujha", "बुझा")
            return Plan(if (off) "Torch band" else "Torch on", listOf(act("flashlight", "on" to !off)))
        }

        // ---- navigation ----
        if (has(t, "neeche", "नीचे", "scroll down")) return Plan("Theek hai", listOf(act("nav", "name" to "scroll_down")))
        if (has(t, "upar", "ऊपर", "scroll up")) return Plan("Theek hai", listOf(act("nav", "name" to "scroll_up")))
        if (has(t, "peeche", "पीछे", "back", "वापस")) return Plan("Theek hai", listOf(act("nav", "name" to "back")))
        if (has(t, "home", "होम")) return Plan("Theek hai", listOf(act("nav", "name" to "home")))
        if (has(t, "notification", "नोटिफिकेशन")) return Plan("Theek hai", listOf(act("nav", "name" to "notifications")))
        if (has(t, "recent", "रिसेंट")) return Plan("Theek hai", listOf(act("nav", "name" to "recents")))

        // ---- alarm ----
        if (has(t, "alarm", "अलार्म")) {
            var h = number(t) ?: return Plan("Kitne baje ka alarm lagaun?", emptyList())
            val m = Regex("(\\d{1,2})[: ](\\d{2})").find(t)?.groupValues?.get(2)?.toIntOrNull() ?: 0
            val pm = has(t, "shaam", "शाम", "raat", "रात", "dopahar", "दोपहर", "pm")
            if (pm && h in 1..11) h += 12
            if (h > 23) return Plan("Ye time samajh nahi aaya", emptyList())
            return Plan("$h baj kar $m minute ka alarm laga diya", listOf(act("alarm", "hour" to h, "minute" to m, "label" to "Sifra")))
        }

        // ---- timer ----
        if (has(t, "timer", "टाइमर")) {
            val n = number(t) ?: return Plan("Kitne ka timer lagaun?", emptyList())
            val secs = when {
                has(t, "ghant", "घंट", "hour") -> n * 3600
                has(t, "second", "sec", "सेकंड") -> n
                else -> n * 60
            }
            return Plan("Timer laga diya", listOf(act("timer", "seconds" to secs)))
        }

        // ---- sms ----
        if (has(t, "message", "sms", "msg", "मैसेज", "मेसेज", "संदेश")) {
            val m = Regex("(.+?)\\s+(ko|को)\\s+(message|sms|msg|मैसेज|मेसेज)?\\s*(bhejo|भेजो|karo|करो|likho|लिखो)?\\s*(ki|कि|ke|ye|ye ki)?\\s*(.*)").find(t)
            val target = m?.groupValues?.get(1)?.replace(Regex("^(send|ek|a)\\s+"), "")?.trim().orEmpty()
            val text = m?.groupValues?.get(6)?.replace(Regex("(bhejo|भेजो|likho|लिखो)$"), "")?.trim().orEmpty()
            if (target.isBlank() || text.isBlank())
                return Plan("Aise bolo: Rahul ko message bhejo ki main late aaunga", emptyList())
            return Plan("", listOf(act("sms", "target" to target, "text" to text)))
        }

        // ---- call ----
        if (has(t, "call", "phone", "कॉल", "फोन", "फ़ोन", "dial")) {
            var target = t
            for (w in listOf("call", "phone", "dial", "कॉल", "फोन", "फ़ोन", "karo", "kardo", "kar do", "lagao", "laga do",
                "करो", "लगाओ", "लगा दो", "ko", "को", "please", "pe", "par")) {
                target = target.replace(Regex("(^|\\s)${Regex.escape(w)}(?=\\s|$)"), " ")
            }
            target = target.replace(Regex("\\s+"), " ").trim()
            if (target.isBlank()) return Plan("Kisko call karun?", emptyList())
            return Plan("", listOf(act("call", "target" to target)))
        }

        // ---- settings ----
        if (has(t, "wifi", "wi-fi", "वाईफाई", "वाई-फाई")) return Plan("WiFi settings khol di", listOf(act("settings", "page" to "wifi")))
        if (has(t, "bluetooth", "ब्लूटूथ")) return Plan("Bluetooth settings khol di", listOf(act("settings", "page" to "bluetooth")))
        if (has(t, "brightness", "display", "ब्राइटनेस")) return Plan("Display settings khol di", listOf(act("settings", "page" to "display")))
        if (has(t, "volume", "sound", "आवाज", "वॉल्यूम")) return Plan("Sound settings khol di", listOf(act("settings", "page" to "sound")))
        if (has(t, "setting", "सेटिंग")) return Plan("Settings khol di", listOf(act("settings", "page" to "main")))

        // ---- search ----
        if (has(t, "search", "google", "dhundo", "khojo", "सर्च", "गूगल", "ढूंढो", "खोजो")) {
            val q = t.replace(Regex("(search|google|dhundo|khojo|karo|kar do|सर्च|गूगल|ढूंढो|खोजो|करो|पर|par|pe|ko)"), " ")
                .replace(Regex("\\s+"), " ").trim()
            if (q.isNotBlank()) return Plan("Search kar rahi hoon", listOf(act("search", "query" to q)))
        }

        // ---- tap ----
        if (has(t, "dabao", "दबाओ", "click", "tap", "क्लिक")) {
            val x = t.replace(Regex("(screen par|screen pe|screen|par|pe|dabao|dabana|click|tap|karo|kar do|दबाओ|क्लिक|करो|button|बटन)"), " ")
                .replace(Regex("\\s+"), " ").trim()
            if (x.isNotBlank()) return Plan("Theek hai", listOf(act("tap_text", "text" to x)))
        }

        // ---- app kholna ----
        if (has(t, "kholo", "khol", "open", "chalao", "start", "खोलो", "खोल", "चलाओ", "ओपन")) {
            val app = t.replace(Regex("(app|ko|kholo|khol do|khol|do|open|karo|chalao|start|please|खोलो|खोल|दो|ओपन|चलाओ|को|ऐप|एप)"), " ")
                .replace(Regex("\\s+"), " ").trim()
            if (app.isNotBlank()) return Plan("", listOf(act("open_app", "app" to app)))
        }

        return Plan(
            "Samajh nahi aaya. Aise bolo: WhatsApp kholo, mummy ko call karo, subah 6 baje alarm lagao, torch on karo.",
            emptyList()
        )
    }
}
