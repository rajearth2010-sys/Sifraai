package com.sifra.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("sifra", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        fun add(v: android.view.View) = root.addView(
            v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        add(TextView(this).apply { text = "Sifra"; textSize = 32f })
        add(TextView(this).apply {
            text = "Step 1: Gemini API key daalo\nStep 2: Permissions do\nStep 3: Accessibility on karo\nStep 4: Start dabao, phir bolo: \"Sifra, WhatsApp kholo\""
            setPadding(0, 16, 0, 32)
        })

        val key = EditText(this).apply {
            hint = "Gemini API key (AIza...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("api_key", ""))
        }
        add(key)

        add(Button(this).apply {
            text = "Key save + Permissions do"
            setOnClickListener {
                prefs.edit().putString("api_key", key.text.toString().trim()).apply()
                requestPermissions(
                    arrayOf(
                        Manifest.permission.RECORD_AUDIO,
                        Manifest.permission.CALL_PHONE,
                        Manifest.permission.SEND_SMS,
                        Manifest.permission.READ_CONTACTS,
                        Manifest.permission.POST_NOTIFICATIONS
                    ), 1
                )
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
            }
        })

        add(Button(this).apply {
            text = "Accessibility settings kholo"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        add(Button(this).apply {
            text = "Sifra START"
            setOnClickListener {
                prefs.edit().putString("api_key", key.text.toString().trim()).apply()
                startForegroundService(Intent(this@MainActivity, SifraService::class.java))
                Toast.makeText(this@MainActivity, "Sifra sun rahi hai", Toast.LENGTH_SHORT).show()
            }
        })

        add(Button(this).apply {
            text = "Sifra STOP"
            setOnClickListener { stopService(Intent(this@MainActivity, SifraService::class.java)) }
        })

        setContentView(root)
    }
}
