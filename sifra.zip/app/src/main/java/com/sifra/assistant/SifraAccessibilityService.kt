package com.sifra.assistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Home/back/scroll/tap jaise screen control ke liye. */
class SifraAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: SifraAccessibilityService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun nav(name: String) {
        when (name) {
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "quick_settings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            "scroll_down" -> scroll(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
            "scroll_up" -> scroll(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
        }
    }

    private fun scroll(action: Int) {
        val node = findScrollable(rootInActiveWindow) ?: return
        node.performAction(action)
    }

    private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) findScrollable(n.getChild(i))?.let { return it }
        return null
    }

    /** Screen par jo text dikh raha hai use tap karta hai. */
    fun tapText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val matches = root.findAccessibilityNodeInfosByText(text)
        for (m in matches) {
            var n: AccessibilityNodeInfo? = m
            while (n != null) {
                if (n.isClickable) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                n = n.parent
            }
        }
        return false
    }
}
