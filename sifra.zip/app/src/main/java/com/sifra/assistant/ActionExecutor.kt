package com.sifra.assistant

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager

/** Actions ko phone par asli me chalata hai. */
class ActionExecutor(private val ctx: Context) {

    /** Call aur SMS se pehle user se "haan" confirm karwate hain. */
    fun needsConfirm(a: Action) = a.type == "call" || a.type == "sms"

    fun confirmText(a: Action): String = when (a.type) {
        "call" -> "${a.args.optString("target")} ko call karun? Haan bolo."
        "sms" -> "${a.args.optString("target")} ko message bhejun: ${a.args.optString("text")}. Haan bolo."
        else -> "Karun? Haan bolo."
    }

    fun run(a: Action, say: (String) -> Unit) {
        try {
            when (a.type) {
                "call" -> {
                    val num = resolveNumber(a.args.optString("target"))
                    if (num == null) say("Ye contact nahi mila")
                    else start(Intent(Intent.ACTION_CALL, Uri.parse("tel:$num")))
                }
                "sms" -> {
                    val num = resolveNumber(a.args.optString("target"))
                    if (num == null) say("Ye contact nahi mila")
                    else {
                        val sms = ctx.getSystemService(SmsManager::class.java)
                        val text = a.args.optString("text")
                        sms.sendMultipartTextMessage(num, null, sms.divideMessage(text), null, null)
                        say("Message bhej diya")
                    }
                }
                "open_app" -> {
                    val pkg = findApp(a.args.optString("app"))
                    val launch = pkg?.let { ctx.packageManager.getLaunchIntentForPackage(it) }
                    if (launch == null) say("Ye app nahi mila") else start(launch)
                }
                "alarm" -> start(Intent(AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(AlarmClock.EXTRA_HOUR, a.args.optInt("hour"))
                    putExtra(AlarmClock.EXTRA_MINUTES, a.args.optInt("minute"))
                    putExtra(AlarmClock.EXTRA_MESSAGE, a.args.optString("label", "Sifra"))
                    putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                })
                "timer" -> start(Intent(AlarmClock.ACTION_SET_TIMER).apply {
                    putExtra(AlarmClock.EXTRA_LENGTH, a.args.optInt("seconds", 60))
                    putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                })
                "search" -> start(Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.args.optString("query")))))
                "flashlight" -> {
                    val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                    cm.setTorchMode(cm.cameraIdList[0], a.args.optBoolean("on", true))
                }
                "settings" -> start(Intent(when (a.args.optString("page")) {
                    "wifi" -> Settings.ACTION_WIFI_SETTINGS
                    "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                    "display" -> Settings.ACTION_DISPLAY_SETTINGS
                    "sound" -> Settings.ACTION_SOUND_SETTINGS
                    else -> Settings.ACTION_SETTINGS
                }))
                "nav" -> {
                    val svc = SifraAccessibilityService.instance
                    if (svc == null) say("Pehle Accessibility me Sifra ko on karo")
                    else svc.nav(a.args.optString("name"))
                }
                "tap_text" -> {
                    val svc = SifraAccessibilityService.instance
                    if (svc == null) say("Pehle Accessibility me Sifra ko on karo")
                    else if (!svc.tapText(a.args.optString("text"))) say("Screen par ye nahi dikha")
                }
            }
        } catch (e: SecurityException) {
            say("Is kaam ki permission nahi hai")
        } catch (e: Exception) {
            say("Ye kaam nahi ho paya")
        }
    }

    private fun start(i: Intent) {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun resolveNumber(target: String): String? {
        if (target.isBlank()) return null
        if (target.replace(Regex("[\\s+-]"), "").all { it.isDigit() }) return target
        val cur = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$target%"), null
        )
        cur?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun findApp(name: String): String? {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .firstOrNull { it.loadLabel(pm).toString().contains(name, ignoreCase = true) }
            ?.activityInfo?.packageName
    }
}
