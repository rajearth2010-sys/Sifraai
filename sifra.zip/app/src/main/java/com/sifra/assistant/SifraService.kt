package com.sifra.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.ServiceCompat
import java.util.Locale
import java.util.concurrent.Executors

/** Hamesha sunta rehta hai. "Sifra ..." bolo to command Claude ko bhejta hai. */
class SifraService : Service(), TextToSpeech.OnInitListener {

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private lateinit var exec: ActionExecutor
    private var brain: ClaudeBrain? = null

    private var speaking = false
    private var awaiting = false
    private var stopped = false
    private var pending: Action? = null

    private val wakeWords = listOf("sifra", "sifara", "cifra", "sifrah", "सिफरा", "सिफ्रा")
    private val yesWords = listOf("haan", "han", "yes", "kar do", "karo", "ok", "theek", "हाँ", "हां")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        exec = ActionExecutor(this)
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val key = getSharedPreferences("sifra", MODE_PRIVATE).getString("api_key", "").orEmpty()
        brain = if (key.isNotBlank()) ClaudeBrain(key) else null
        startAsForeground()
        listen()
        return START_STICKY
    }

    override fun onDestroy() {
        stopped = true
        recognizer?.destroy()
        tts.shutdown()
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("sifra", "Sifra", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "sifra")
            .setContentTitle("Sifra sun rahi hai")
            .setContentText("\"Sifra\" bolkar command do")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    override fun onInit(status: Int) {
        tts.language = Locale("hi", "IN")
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onError(id: String?) { main.post { speaking = false; listen() } }
            override fun onDone(id: String?) { main.post { speaking = false; listen() } }
        })
    }

    // ---------- sunna ----------

    private fun listen() {
        if (stopped || speaking) return
        main.post {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(listener)
            }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            }
            recognizer?.startListening(i)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull().orEmpty()
            handle(text)
        }
        override fun onError(error: Int) { main.postDelayed({ listen() }, 700) }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    // ---------- samajhna ----------

    private fun handle(text: String) {
        val t = text.lowercase().trim()
        if (t.isEmpty()) { listen(); return }

        pending?.let { p ->
            pending = null
            if (yesWords.any { t.contains(it) }) exec.run(p) { say(it) } else say("Theek hai, cancel kar diya")
            if (!speaking) listen()
            return
        }

        val hit = wakeWords.firstOrNull { t.contains(it) }
        if (hit == null && !awaiting) { listen(); return }
        awaiting = false

        val cmd = if (hit != null) t.substringAfter(hit).trim() else t
        if (cmd.isBlank()) { awaiting = true; say("Ji, boliye"); return }
        think(cmd)
    }

    private fun think(cmd: String) {
        val b = brain
        if (b == null) { say("Pehle app me Gemini API key daalo"); return }
        io.execute {
            val plan = try { b.plan(cmd) } catch (e: Exception) { Plan("Net ya Gemini me problem hai", emptyList()) }
            main.post { runPlan(plan) }
        }
    }

    private fun runPlan(plan: Plan) {
        var reply = plan.say
        for (a in plan.actions) {
            if (exec.needsConfirm(a)) {
                pending = a
                reply = exec.confirmText(a)
                break
            }
            exec.run(a) { reply = it }
        }
        if (reply.isBlank()) listen() else say(reply)
    }

    private fun say(text: String) {
        speaking = true
        recognizer?.cancel()
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sifra")
    }
}
