# Sifra: voice personal assistant (Android)

## Kaise chalayein
1. Android Studio me `sifra` folder kholo, Gradle sync hone do.
2. Phone USB se jodo (USB debugging on) aur Run dabao.
3. App me apni Claude API key daalo (console.anthropic.com se).
4. "Key save + Permissions do" dabao, sab Allow karo (Display over other apps bhi on karo, warna call/app background me nahi khulenge).
5. "Accessibility settings kholo" > Sifra > ON (home, back, scroll, tap ke liye).
6. "Sifra START" dabao.

## Bolke dekho
- "Sifra, WhatsApp kholo"
- "Sifra, mummy ko call karo" (pehle haan puchhegi)
- "Sifra, Rahul ko message bhejo ki main late aaunga"
- "Sifra, subah 6 baje ka alarm lagao"
- "Sifra, 10 minute ka timer"
- "Sifra, torch on karo"
- "Sifra, neeche scroll karo" / "peeche jao" / "home jao"
- "Sifra, screen par Send dabao"
- "Sifra, aaj ka mausam kaisa rahega" (search)

## Safety
- Call aur SMS se pehle Sifra "haan" bolne par hi karti hai.
- API key sirf phone ki private storage me rehti hai.
- Payment/banking apps par kaam karwane ke liye isse mat use karo.

## Files
- `SifraService.kt`: sunna, wake word "sifra", bolna
- `ClaudeBrain.kt`: Claude API se command ko actions me badalna
- `ActionExecutor.kt`: call, sms, app, alarm, timer, torch, settings
- `SifraAccessibilityService.kt`: home/back/scroll/tap
